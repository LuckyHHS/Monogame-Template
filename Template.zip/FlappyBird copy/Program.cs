﻿using var game = new FlappyBird.Game1();
game.Run();
