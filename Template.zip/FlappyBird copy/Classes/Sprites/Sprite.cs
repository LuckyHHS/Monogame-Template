using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


public class Sprite
{
    // Privates
    private Vector2 _position;
    private float _scale;
    private Color _tint;
    private Rectangle rectangle;
    private Texture2D _texture;

    // Publics

    /// <summary>
    /// The texture of the sprite.
    /// </summary>
    public Texture2D Texture
    {
        get
        {
            return _texture;
        }

        set
        {
            _texture = value;
            UpdateRectangle();
        }
    }

    /// <summary>
    /// The position of the sprite.
    /// </summary>
    public Vector2 Position
    {
        get
        {
            return _position;
        }

        set
        {
            _position = value;
            UpdateRectangle();
        }
    }

    /// <summary>
    /// The scale of the sprite. Defaults to 1f.
    /// </summary>
    public float Scale
    {
        get
        {
            return _scale;
        }

        set
        {
            _scale = value;
            UpdateRectangle();
        }
    }

    /// <summary>
    /// The tint of the sprite. Defaults to Color.White.
    /// </summary>
    public Color Tint
    {
        get
        {
            return _tint;
        }

        set
        {
            _tint = value;
            UpdateRectangle();
        }
    }



    /// <summary>
    /// Creates a new sprite object.
    /// </summary>
    /// <param name="texture"></param>
    /// <param name="position"></param>
    public Sprite(Texture2D texture, Vector2 position)
    {
        this._position = position;
        this._texture = texture;
        this._scale = 1f;
        this._tint = Color.White;

        // Update the base rectangle.
        UpdateRectangle();
    }

    /// <summary>
    /// Refreshs the rectangle with the current properties.
    /// </summary>
    public void UpdateRectangle()
    {
        rectangle = new Rectangle((int)_position.X, (int)_position.Y, (int)(_texture.Width * _scale), (int)(_texture.Height * _scale));
    }

    /// <summary>
    /// Move the sprite in a specific direction.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void Move(int x, int y = 0)
    {
        this.Position = new Vector2(this.Position.X + x, this.Position.Y + y);
    }

    /// <summary>
    /// Called every frame to draw sprite. Can be overridded, but use base.
    /// </summary>
    /// <param name="_spriteBatch"></param>
    public virtual void Draw(SpriteBatch _spriteBatch)
    {
        if (_texture == null) {Console.WriteLine("Sprite has a null texture. Not currently drawing it."); return; }
        _spriteBatch.Draw(_texture, rectangle, _tint);
    }

    /// <summary>
    /// Called every frame for update logic. Meant to be overridded.
    /// </summary>
    /// <param name="gameTime"></param>
    public virtual void Update(GameTime gameTime)
    {

    }
}
