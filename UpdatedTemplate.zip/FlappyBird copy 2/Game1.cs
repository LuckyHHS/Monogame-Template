﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FlappyBird;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    
    public List<Sprite> sprites;
    private GameLoop gameLoop;
    public static Game1 game;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        sprites = new();
        gameLoop = new GameLoop();
        Game1.game = this;
    }

    protected override void Initialize()
    {
        // Game loop init.
        gameLoop.Start();

        // Initalize game.
        Initialize init = new Initialize();
        init.OnInitialize();

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        
        // Game loop load.
        gameLoop.game = this;
        gameLoop.Preload(this.Content, ref sprites);

        // Load game content.
        LoadContent init = new LoadContent();
        init.OnLoadContent(this.Content, ref sprites);
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // Update game loop.
        gameLoop.Update(gameTime);    

        // Update game.
        foreach (Sprite sprite in sprites)
        {
            sprite.Update(gameTime);
        }

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);

        // Draw sprites.
        _spriteBatch.Begin();
        foreach (Sprite sprite in sprites)
        {
            sprite.Draw(_spriteBatch);
        }
        _spriteBatch.End();

        base.Draw(gameTime);
    }
}
