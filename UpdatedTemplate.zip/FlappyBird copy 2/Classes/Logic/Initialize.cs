using FlappyBird;

public class Initialize
{
    // Called when the game loads first.
    public void OnInitialize()
    {

    }
}