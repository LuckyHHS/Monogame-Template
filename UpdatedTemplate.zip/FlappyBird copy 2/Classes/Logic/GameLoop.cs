using System.Collections.Generic;
using FlappyBird;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

public class GameLoop
{
    public Game1 game; // Direct reference to the game. Also use Game1.game to access in other files.

    // Called when the game starts, use to load content.
    public void Preload(ContentManager content, ref List<Sprite> sprites)
    {
       
    }

    // Called when the program initalizes.
    public void Start()
    {
        
    }

    // Called every frame.
    public void Update(GameTime gameTime)
    {
        
    }
}