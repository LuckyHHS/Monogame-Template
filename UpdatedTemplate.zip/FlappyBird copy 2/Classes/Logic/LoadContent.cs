using System.Collections.Generic;
using FlappyBird;
using Microsoft.Xna.Framework.Content;

public class LoadContent
{
    // Called when the game is loading content.
    public void OnLoadContent(ContentManager content, ref List<Sprite> sprites)
    {
        
    }


}